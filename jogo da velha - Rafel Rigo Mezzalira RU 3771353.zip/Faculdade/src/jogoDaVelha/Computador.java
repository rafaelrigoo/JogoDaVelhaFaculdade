package jogoDaVelha;

import java.util.Random;

public class Computador {
    
	public Random jogadaComputador = new Random();
	protected int[] tentativa = new int[2];
	protected int comp;
   
    //M�todo que ser� sobrescrito pela estrat�gia selecionada.
	public void jogar(Tabuleiro tabuleiro){
    	
      }
    
	//M�todo para verificar se a jogada feita j� nao est� marcada.
    public boolean checaTentativa(int[] tentativa, Tabuleiro tabuleiro){
        if(tabuleiro.getPosicao(tentativa) == 0)
            return true;
        else
            return false;
            
    }
}
