package jogoDaVelha;

public class EstrategiaA extends Computador{
	
	//Primeira estrat�gia do computador, jogando por linha.
	@Override 
	public void jogar(Tabuleiro tabuleiro){
		   
	    	boolean checagem = true;
	    	int contadorColuna = -1;
	    	    	
	    	while(checagem) {
	    		contadorColuna++;
	    		
	    		for(int linha = 0; linha < 3; linha++) {
	    			tentativa[0] = linha;
	    			    			
	    			if(checaTentativa(tentativa, tabuleiro)) {
	    				checagem = false;
	    				tabuleiro.setPosicao(tentativa, comp);
	    				return;
	    			}   			
	    		}
	    		tentativa[1] = contadorColuna;
	    		
	    	}
	 }
}
