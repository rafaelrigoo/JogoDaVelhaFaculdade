package jogoDaVelha;

public class EstrategiaB extends Computador{
	
	//Segunda estrat�gia do computador, jogando aleat�rio.
	@Override
	public void jogar(Tabuleiro tabuleiro){
    	do{
            do{
                tentativa[0] = jogadaComputador.nextInt(3) + 1;
                
            }while( tentativa[0] > 3 ||tentativa[0] < 1);
            
            do{
                tentativa[1] = jogadaComputador.nextInt(3) + 1;
  
            }while(tentativa[1] > 3 ||tentativa[1] < 1);
            
            tentativa[0]--; 
            tentativa[1]--;

        }while( !checaTentativa(tentativa, tabuleiro) );
    	tabuleiro.setPosicao(tentativa, comp);
 }
}
