package jogoDaVelha;

public class EstrategiaC extends Computador{
	
	//Terceira estrat�gia do computador, jogando por coluna.
	@Override
	public void jogar(Tabuleiro tabuleiro){
	    	boolean checagem = true;
	    	int contadorLinha = -1;
	    	    	
	    	while(checagem) {
	    		contadorLinha++;
	    		
	    		for(int coluna = 0; coluna < 3; coluna++) {
	    			tentativa[1] = coluna;
	    			    			
	    			if(checaTentativa(tentativa, tabuleiro)) {
	    				checagem = false;
	    				tabuleiro.setPosicao(tentativa, comp);
	    				return;
	    			}   			
	    		}
	    		tentativa[0] = contadorLinha;
	    	}
	    }
}
