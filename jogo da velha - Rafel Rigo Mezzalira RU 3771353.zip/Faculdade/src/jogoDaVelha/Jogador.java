package jogoDaVelha;

import java.util.Scanner;

public class Jogador {
    public Scanner entrada = new Scanner(System.in);
    protected int[] tentativa = new int[2];
    protected int jogador;

    
    public Jogador(int humano){
        jogador = humano;
    }
   
    //M�todo para verificar e definir as jogadas da pessoa.
    public void jogar(Tabuleiro tabuleiro){
        tentativaJogador(tabuleiro);
        tabuleiro.setPosicao(tentativa, jogador);
    }
    
  //M�todo para verificar se a jogada feita j� nao est� marcada.
    public boolean checaTentativa(int[] tentativa, Tabuleiro tabuleiro){
        if(tabuleiro.getPosicao(tentativa) == 0)
            return true;
        else
            return false;
    }
    
    //M�todo para validar a entrada da pessoa.
    public void conferirJogada(Tabuleiro tabuleiro) {
    	if( tentativa[0] > 3 ||tentativa[0] < 1)
            System.out.println("Entrada Inv�lida. Por favor digite 1, 2 ou 3");
    }
    
    //M�todo que recebe a linha e a coluna referente a jogada da pessoa.
    public void tentativaJogador(Tabuleiro tabuleiro){
        do{
            do{
                System.out.print("Linha: ");
                tentativa[0] = entrada.nextInt();
                
                conferirJogada(tabuleiro);
               
            }while( tentativa[0] > 3 ||tentativa[0] < 1);
            
            do{
                System.out.print("Coluna: ");
                tentativa[1] = entrada.nextInt();
                
                conferirJogada(tabuleiro);
                
            }while(tentativa[1] > 3 ||tentativa[1] < 1);
            
            tentativa[0]--; 
            tentativa[1]--;
            
            if(!checaTentativa(tentativa, tabuleiro))
                System.out.println("Esse local j� foi marcado. Tente outro.");
        }while( !checaTentativa(tentativa, tabuleiro) );
    }
    
}