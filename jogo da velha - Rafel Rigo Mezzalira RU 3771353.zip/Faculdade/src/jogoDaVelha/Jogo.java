package jogoDaVelha;

import java.util.Scanner;

public class Jogo {
    private Tabuleiro tabuleiro;
    private int rodada=1, vez=1;
    private Jogador jogador1 = new Jogador(1);
    private Computador jogador2 = new Computador();
    public Scanner entrada = new Scanner(System.in);

    
//M�todo para descobrir qual estrat�gia a pessoa quer enfrentar.
    
    int opcao=0;
    
    public void escolherEstrategia(){
        System.out.println("Qual estrat�gia voc� gostaria de enfrentar ?");
        System.out.println("1, 2 ou 3 ?");
        System.out.print("Op��o: ");
       	opcao = entrada.nextInt();
        if(opcao != 1 && opcao != 2 && opcao != 3)
            System.out.println("Op��o inv�lida! Tente novamente");
    
    while(opcao != 1 && opcao != 2 && opcao !=3);
       
   }
    
    
    //M�todo para iniciar o jogo. 
    public Jogo(){
        tabuleiro = new Tabuleiro();
        escolherEstrategia();
        
		if(opcao == 1) 
		    jogador2 = new EstrategiaA();
		    	
    	else if(opcao == 2)
    		jogador2 = new EstrategiaB();
    	
    	else
    		jogador2 = new EstrategiaC();
        
        while( Jogar());
    }
    
    //M�todo para din�mica do jogo, alterando a vez de cada jogador e chamando os m�todos para verificar se existe ganhador ou se esta empatado
    public boolean Jogar(){
        if(ganhou() == 0 ){
            System.out.println("----------------------");
            System.out.println("\nRodada "+rodada);
                                
            if(vez() == 1)
                jogador1.jogar(tabuleiro);
            else
                jogador2.jogar(tabuleiro);
            
            vez++;
            rodada++;

            return true;
        } else{
            if(ganhou() == -1 )
                System.out.println("Voc� ganhou, Parab�ns!!!");
            else if(ganhou() == 1)
                System.out.println("III, voc� n�o conseguiu vencer o computador, tente novamente!!!");
            else if(tabuleiro.tabuleiroCompleto()){
                System.out.println("Tabuleiro Completo. Jogo empatado");
                return false;
            }
            return false;
        }
            
    }
    
    //M�todo para imprimir na tela de quem � a vez de jogar.
    public int vez(){
        if(vez%2 == 1) {
            System.out.println("Sua vez de jogar");
        	return 1;
        }
        else {
         System.out.println("� a vez do computador jogar");
        	return 2;
        }
    }
    
    
    //M�todo para verificar se algum dos jogadores ganhou na rodada.
    public int ganhou(){
        if(tabuleiro.verificarLinhas() == 1)
            return 1;
        if(tabuleiro.verificarColunas() == 1)
            return 1;
        if(tabuleiro.verificarDiagonais() == 1)
            return 1;
        
        if(tabuleiro.verificarLinhas() == -1)
            return -1;
        if(tabuleiro.verificarColunas() == -1)
            return -1;
        if(tabuleiro.verificarDiagonais() == -1)
            return -1;
        
        return 0;
    }
    
    
}

