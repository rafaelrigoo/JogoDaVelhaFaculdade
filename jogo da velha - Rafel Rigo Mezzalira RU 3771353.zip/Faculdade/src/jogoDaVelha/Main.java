package jogoDaVelha;

public class Main {

	public static void main(String[] args) {
		Jogo jogo = new Jogo();
		
	}

}
