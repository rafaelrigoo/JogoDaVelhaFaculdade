package jogoDaVelha;

public class Tabuleiro {

	 public int[][] tabuleiro= new int[3][3];
	    
	 //M�todo para desenhar o tabuleiro durante o jogo.  
	    public void exibirTabuleiro(){
	        System.out.println();
	        for(int linha = 0 ; linha < 3 ; linha++){
	        
	            for(int coluna = 0 ; coluna < 3 ; coluna++){
	                
	                if(tabuleiro[linha][coluna] == -1){
	                    System.out.print(" X ");
	                }
	                if(tabuleiro[linha][coluna] == 1){
	                    System.out.print(" O ");
	                }
	                if(tabuleiro[linha][coluna] == 0){
	                    System.out.print("   ");
	                }
	                
	                if(coluna==0 || coluna==1)
	                    System.out.print("|");
	            }
	            System.out.println();
	        }
	                
	    }
	    
	    //M�todo para pegar e definir a posi��o.
	    public int getPosicao(int[] tentativa){
	        return tabuleiro[tentativa[0]][tentativa[1]];
	    }
	    
	    public void setPosicao(int[] tentativa, int jogador){
	        if(jogador == 1)
	            tabuleiro[tentativa[0]][tentativa[1]] = -1;
	        else
	            tabuleiro[tentativa[0]][tentativa[1]] = 1;
	        
	        exibirTabuleiro();
	    }

//	   M�todos para verificar do tabuleiro para ver se algum dos jogadores venceu na rodada.
	    
	    public int verificarLinhas(){
	        for(int linha = 0 ; linha < 3 ; linha++){

	            if( (tabuleiro[linha][0] + tabuleiro[linha][1] + tabuleiro[linha][2]) == -3)
	                return -1;
	            if( (tabuleiro[linha][0] + tabuleiro[linha][1] + tabuleiro[linha][2]) == 3)
	                return 1;
	        }
	        
	        return 0;
	                
	    }
	    
	    public int verificarColunas(){
	        for(int coluna = 0 ; coluna < 3 ; coluna++){

	            if( (tabuleiro[0][coluna] + tabuleiro[1][coluna] + tabuleiro[2][coluna]) == -3)
	                return -1;
	            if( (tabuleiro[0][coluna] + tabuleiro[1][coluna] + tabuleiro[2][coluna]) == 3)
	                return 1;
	        }
	        
	        return 0;
	                
	    }
	    
	    public int verificarDiagonais(){
	        if( (tabuleiro[0][0] + tabuleiro[1][1] + tabuleiro[2][2]) == -3)
	            return -1;
	        if( (tabuleiro[0][0] + tabuleiro[1][1] + tabuleiro[2][2]) == 3)
	            return 1;
	        if( (tabuleiro[0][2] + tabuleiro[1][1] + tabuleiro[2][0]) == -3)
	            return -1;
	        if( (tabuleiro[0][2] + tabuleiro[1][1] + tabuleiro[2][0]) == 3)
	            return 1;
	        
	        return 0;
	    }

	    //m�todo para verificar se o tabuleiro est� completo e o jogo terminou.
	    public boolean tabuleiroCompleto(){
	        for(int linha = 0 ; linha < 3 ; linha++)
	            for(int coluna=0 ; coluna<3 ; coluna++)
	                if( tabuleiro[linha][coluna]==0 )
	                    return false;
	        return true;
	    }
	
}
